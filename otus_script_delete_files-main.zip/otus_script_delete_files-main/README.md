# otus_scripd_delete_files
Bash скрипт удаляет файлы с заданным расширением и на вход получает 
